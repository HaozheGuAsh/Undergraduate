// Filename:hello.cpp
// this program will print helloworld
// haozhe gu 999200555
#include<iostream>
using std::cout;
using std::cin;
using std::endl;

//Main Function

int main()
{
  cout<<"Hello ECS40 from 00555"<<endl;
  return 0;
}
