function out = sigmoid(x)
out = 1 ./(1 + exp(-x));

end