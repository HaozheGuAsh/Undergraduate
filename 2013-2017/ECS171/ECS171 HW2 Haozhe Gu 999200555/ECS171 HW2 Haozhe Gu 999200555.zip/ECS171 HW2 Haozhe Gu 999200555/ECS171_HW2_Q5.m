clearvars all;
result = ANN_Predict([12],50);
fprintf('Predicted Category is: %s \n',result); 