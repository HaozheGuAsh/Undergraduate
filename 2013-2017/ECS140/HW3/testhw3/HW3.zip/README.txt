Haozhe Gu,999200555

Program goes well
