public class e2c {
 
    public static void main(String args[]) {
	Scan scanner = new Scan();
	new Parser(scanner);
    }
}
